class Technology < ApplicationRecord
  belongs_to :portfolio
end
