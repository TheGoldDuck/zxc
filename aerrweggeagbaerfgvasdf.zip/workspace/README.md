![logo](https://s3.amazonaws.com/bottega-devcamp/bottega-devcamp.png)

## Hi there! Welcome to Bottega Devcamp

### Instructions to enter into the bash shell

To startup the Postgres database, the command is:

```
sudo service postgresql start
```

To generate a new rails application, the command is:

```
rails new AppName -T --database=postgresql
```

Change into the app:

```
cd AppName
```

Create and migrate the database:

```
rails db:create && rails db:migrate
```

To run the Rails server on C9, the command is:

```
rails s -b $IP -p $PORT == 's'
```
To start the postgresql server:
```
sudo service postgresql start == 'startpost'
```

For more information on how to use Cloud9, visit http://docs.c9.io for our documentation. If you want, you can also go watch some training videos at
http://www.youtube.com/user/c9ide.

Good luck with the coding!


# Edited Here-Down

Remember to use the debugging methods mentioned it the course!
- Puts Debugging
- Byebug
- Pry

     Bug demo: (MAY NOT WORK EVERY TIME!) 2 of 20 blogs showing, not good
     @blogs = Blog.limit(2)
     puts @blogs.inspect


     Displays information, on said bug, in the console.

     Can put: 'puts "*" * 500' brfore and after line 12
     to isolate the desired information.


     byebug


     byebug isolates what stage the bug appears


     Can look through your application while it
     is suspeneded until 'byebug' isn't called.


     Have a plan to place byebug, don't place in
     random places!
     To continue type "continue"


     pry


     Cleaner than byebug


     Add '<% binding.pry %>' to the origin of the errors
     Allows testing in the terminal to find the bug.
     To exit, type "exit"


#    Add comments to test templates and anything in general




### ***DERP***
```
                           ________
                          /        \
    __________________    | IMA    |
   /                  \   | Whale! |
  |                    | <_________/
  |                    |
  | .____________.      \__/|
   \______________________/\|
     \/    \/



      /\
     /  \
    /    \
   /      \
  /        \
 /          \
/____________\

```